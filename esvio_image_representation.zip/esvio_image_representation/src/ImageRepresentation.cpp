#include <esvio_image_representation/ImageRepresentation.h>
#include <esvio_image_representation/TicToc.h>
#include <opencv2/calib3d/calib3d.hpp>
#include <std_msgs/Float32.h>
#include <glog/logging.h>
#include <thread>

//#define ESVIO_REPRESENTATION_LOG

namespace esvio_image_representation 
{
ImageRepresentation::ImageRepresentation(ros::NodeHandle & nh, ros::NodeHandle nh_private) : nh_(nh)
{
  // setup subscribers and publishers
  event_sub_ = nh_.subscribe("events", 0, &ImageRepresentation::eventsCallback, this);
  camera_info_sub_ = nh_.subscribe("camera_info", 1, &ImageRepresentation::cameraInfoCallback, this);
  sync_topic_ = nh_.subscribe("sync", 1, &ImageRepresentation::syncCallback, this);
  image_transport::ImageTransport it_(nh_);
  image_representation_pub_ = it_.advertise("image_representation", 5);
  image_representation_temp_pub_ = it_.advertise("image_representation_temp", 5);

  // system parameters
  nh_private.param<bool>("use_sim_time", bUse_Sim_Time_, true);
//  nh_private.param<bool>("ignore_polarity", ignore_polarity_, true);
  int representation_mode;
  nh_private.param<int>("representation_mode", representation_mode, 0);
  representation_mode_ = (RepresentationMode)representation_mode;
//  nh_private.param<int>("median_blur_kernel_size", median_blur_kernel_size_, 1);
  nh_private.param<int>("max_event_queue_len", max_event_queue_length_, 20);

  // system variables
  bCamInfoAvailable_ = false;
  bSensorInitialized_ = false;
  if(pEventQueueMat_)
    pEventQueueMat_->clear();
  sensor_size_ = cv::Size(0,0);

  // local parameters
  nh_private.param<bool>("use_stereo_cam", bUseStereoCam_, true);
  nh_private.param<double>("decay_ms", decay_ms_, 30);
  decay_sec_  = decay_ms_ / 1000.0;
  nh_private.param<int>("SILC_r", r_, 3);
  SILC_bound_ = (2*r_+1)*(2*r_+1);
  nh_private.param<int>("TOS_k", k_tos_, 3);
  nh_private.param<int>("TOS_T", T_tos_, 241);
//  T_tos_ = 241; //2 * 2 * k_tos_;
  nh_private.param<int>("DiST_alpha", alpha_, 3);
  nh_private.param<int>("DiST_rho", rho_, 2);
  nh_private.param<double>("DiST_truncate", truncate_, 0.5);
  nh_private.param<int>("substraction_delta", substraction_delta_, 5);
}

ImageRepresentation::~ImageRepresentation()
{
  image_representation_pub_.shutdown();
  image_representation_temp_pub_.shutdown();
}

void ImageRepresentation::init(int width, int height)
{
  sensor_size_ = cv::Size(width, height);
  bSensorInitialized_ = true;
  pEventQueueMat_.reset(new EventQueueMat(width, height, max_event_queue_length_));
  ROS_INFO("Sensor size: (%d x %d)", sensor_size_.width, sensor_size_.height);

//  most_recent_ts_map_ = cv::Mat::zeros(sensor_size_, CV_64F);
  representation_TS_ = cv::Mat::zeros(sensor_size_, CV_64F);
  representation_SILC_ = cv::Mat::zeros(sensor_size_, CV_8UC1);
  representation_SILC2_ = cv::Mat::zeros(sensor_size_, CV_8UC1);
  representation_TOS_ = cv::Mat::zeros(sensor_size_, CV_8UC1);
  representation_TOS2_ = cv::Mat::zeros(sensor_size_, CV_64F);
  representation_DiST_ = cv::Mat::zeros(sensor_size_, CV_64F);
  representation_DiTTOS_ = cv::Mat::zeros(sensor_size_, CV_8UC1);;
}

double cal_contrast(cv::Mat & src_img)
{
  // for(int y = 0; y < src_img.rows; y++){
  //   for(int x = 0; x < src_img.cols; x++){
  //     if(src_img.ptr<double>(y)[x] == 1.0)
  //     {
  //       src_img.ptr<double>(y)[x] = 0;
  //     }
  //   }
  // }

  double mean = 0;
  double sums = 0;
  for(int y = 0; y < src_img.rows; y++){
    for(int x = 0; x < src_img.cols; x++){
      mean += src_img.ptr<double>(y)[x];
      if(src_img.ptr<double>(y)[x] != 0)
      {
        sums++;
      }
    }
  }
  if(sums == 0)
    return 0;
  
  mean = mean / sums;
  //std::cout << "This is mean:" << mean << std::endl;

  double contrast = 0;
  for(int y = 0; y < src_img.rows; y++){
    for(int x = 0; x < src_img.cols; x++){
      if(src_img.ptr<double>(y)[x] != 0)
      {
        contrast += pow((src_img.ptr<double>(y)[x] - mean), 2);
      }
    }
  }
  //contrast = contrast / (src_img.rows * src_img.cols);
  contrast = contrast / sums;
  return contrast;
}

void event_filter(cv::Mat & src_img)
{
  cv::Mat filter_image = src_img.clone();
  //cv::GaussianBlur(representation_TOS_, filiter_image, cv::Size(5, 5),5 ,5 );
      //cv::Mat filiter_image2 = cv::Mat::zeros(sensor_size_, CV_8UC1);
      //filiter_image2 = representation_TOS_.clone();
      //uchar* ptr = filiter_image.ptr();
      int kernel_size = 1;
      for(int x = 0; x < src_img.cols; x++){
        for(int y = 0; y < src_img.rows;y++){
          //std::cout << __LINE__ << std::endl;
          if(x - kernel_size < 0 || x + kernel_size >= src_img.cols || y - kernel_size < 0 || y + kernel_size >= src_img.rows )
            continue;
          //std::cout << __LINE__ << std::endl;
          int score = 0;
          for(int i = -kernel_size; i <= kernel_size; i++){
            for(int j = -kernel_size; j <= kernel_size; j++){
              score += src_img.at<uchar>(y + i, x + j);
            }
          }
          if(score < 256){
            filter_image.at<uchar>(y, x) = 0;
          }
        }

      }
  src_img = filter_image.clone();
}

void edge_extraction(cv::Mat & src_img, cv::Mat & dst_img)
{
  cv::Mat xgrad;  //x方向上的梯度
	cv::Mat ygrad;  //y方向上的梯度
	cv::Mat xygrad;
  //medianBlur(src_img, src_img, 3);
	Scharr(src_img, xgrad, CV_8U, 1, 0, 3);  //可以理解为加强的Sobel算子
	Scharr(src_img, ygrad, CV_8U, 0, 1, 3);

	// cv::Sobel(src_img, xgrad, CV_8U, 1, 0, 3);
	// Sobel(src_img, ygrad, CV_8U, 0, 1, 3);
	cv::convertScaleAbs(xgrad, xgrad);    //把xgrad统一变成正的
	cv::convertScaleAbs(ygrad, ygrad);     //把ygrad统一变成正的
	//使用按照权重相加的方法将xy两个方向的计算结果进行整合。
	//addWeighted(xgrad, 0.5, ygrad, 0.5, 0, xygrad);

	//绝对值相加
	cv::Mat SobelOutPut1;
	SobelOutPut1= cv::Mat(xgrad.size(), xgrad.type());
	int width = xgrad.cols;
	int height = ygrad.rows;
	for (int row = 0; row < height; row++) {
		for (int col = 0; col < width; col++) {
			int xg = xgrad.at<uchar>(row, col);
			int yg = ygrad.at<uchar>(row, col);
			int xy = (xg + yg)/5;
			SobelOutPut1.at<uchar>(row, col) = cv::saturate_cast<uchar>(xy);
		}
	}
  SobelOutPut1.convertTo(SobelOutPut1, CV_64F);
  cv::normalize(SobelOutPut1, SobelOutPut1, 0, 1 ,cv::NORM_MINMAX);
  //SobelOutPut1.convertTo(SobelOutPut1, CV_8UC1);
  dst_img = SobelOutPut1.clone();

}

void ImageRepresentation::createImageRepresentationAtTime(const ros::Time& external_sync_time)
{
  std::lock_guard<std::mutex> lock(data_mutex_);

  if(!bSensorInitialized_ || !bCamInfoAvailable_)
    return;

  cv::Mat filiter_image = cv::Mat::zeros(sensor_size_, CV_64F);
  cv::Mat rectangle_image = cv::Mat::zeros(cv::Size(80, 80), CV_8U);
  cv::Mat TOS_copy = cv::Mat::zeros(sensor_size_, CV_8UC1);
  if(representation_mode_ == TS)
  {
    cv::Mat divide_image = cv::Mat(sensor_size_, CV_64F, cv::Scalar(decay_sec_));
    representation_TS_.setTo(cv::Scalar(0));
    TicToc t;
    // Compute TS
    for(int y=0; y<sensor_size_.height; ++y)
    {
      for(int x=0; x<sensor_size_.width; ++x)
      {
        dvs_msgs::Event most_recent_event_at_coordXY_before_T;
        if(pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &most_recent_event_at_coordXY_before_T))
        {
          const ros::Time& most_recent_stamp_at_coordXY = most_recent_event_at_coordXY_before_T.ts;
          if(most_recent_stamp_at_coordXY.toSec() > 0)
          {
            const double dt = (external_sync_time - most_recent_stamp_at_coordXY).toSec();
            representation_TS_.at<double>(y,x) = std::exp(-dt / decay_sec_);//-dt /decay_sec_;/
          }
        } // a most recent event is available
        // else{
        //   representation_TS_.at<double>(y,x) = -1000000;
        // }
      }// loop x
    }// loop y
    //cv::divide(representation_TS_, divide_image, representation_TS_);
    //cv::exp(representation_TS_, representation_TS_);
    // double contrast = cal_contrast(representation_TS_);
    // std::cout << "This is Contrast:" << contrast << std::endl;
    // if(contrast > 45)
      filiter_image = representation_TS_.clone();
      std::cout << "use time:" << t.toc() << std::endl;
    // else
      //filiter_image = cv::Mat::zeros(sensor_size_, CV_64F);
      //cv::Canny(representation_TS_,filiter_image,15,130,3);
      //filiter_image.setTo(cv::Scalar(0));
       //medianBlur(representation_TS_, filiter_image, 3);

      //   for(int y = 0; y < sensor_size_.height; y++){
      //     for(int x = 0; x < sensor_size_.width;x++){
      //       double score = filiter_image.ptr<double>(y)[x];
      //       if(score < 0.55 && score > 0.45){
      //         continue;
      //       }else{
      //         filiter_image.at<double>(y, x) = 0.0;
      //       }
      //     }
      // }
  }
  TicToc t_Linear_TS;
  if(representation_mode_ == Linear_TS)
  {
    std::cout << "x_size:" << x_.size() << std::endl;
    std::cout << "InvolvedEvents_size" << InvolvedEvents_.size() << std::endl;
    TicToc t;
    double external_t = external_sync_time.toSec();
    //double decay_sec = decay_ms_ / 1000.0;

    int start_event = 0;
    int end_event = 0;

    {
      if (t_.empty())
        return;

      auto iter1 = lower_bound(t_.begin(), t_.end(), external_t - decay_sec_, std::less<double>());//
      auto iter2 = lower_bound(t_.begin(), t_.end(), external_t, std::less<double>());
      start_event = iter1 - t_.begin();
      end_event = iter2 - t_.begin();

      x_buffer_.swap(x_);
      y_buffer_.swap(y_);
      t_buffer_.swap(t_);
    }
    double map[480][640];
    for(int i = 0;i < 480; i++)
    {
      for(int j = 0; j < 640; j++)
      {
        map[i][j] = -100000;
      }
    }

    auto x_it = x_buffer_.begin() + start_event;
    auto y_it = y_buffer_.begin() + start_event;
    for(auto t_it = t_buffer_.begin() + start_event; 
      t_it != t_buffer_.begin() + end_event; ++x_it, ++y_it, ++t_it)
    {
    
      map[*y_it][*x_it] = (*t_it - external_t) / decay_sec_;
    }
    representation_TS_ = cv::Mat(sensor_size_, CV_64F, map);
    //cv::Mat temp = (representation_TS_ - external_t) * (1 / decay_sec_);
    cv::exp(representation_TS_, representation_TS_);
    std::cout << "Linear_TS use time:" << t.toc() << std::endl;
  }

  if(representation_mode_ == TS2)
  {
    representation_TS_.setTo(cv::Scalar(0));
    t_new_most_current_events_ = 0;
    t_old_most_current_events_ = DBL_MAX;
    // Compute TS
    for(int y=0; y<sensor_size_.height; ++y)
    {
      for(int x=0; x<sensor_size_.width; ++x)
      {
        dvs_msgs::Event most_recent_event_at_coordXY_before_T;
        if(pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &most_recent_event_at_coordXY_before_T))
        {
          const ros::Time& most_recent_stamp_at_coordXY = most_recent_event_at_coordXY_before_T.ts;
          if(most_recent_stamp_at_coordXY.toSec() > 0)
          {
            if(most_recent_stamp_at_coordXY.toSec() > t_new_most_current_events_)
              t_new_most_current_events_ = most_recent_stamp_at_coordXY.toSec();
            if(most_recent_stamp_at_coordXY.toSec() < t_old_most_current_events_)
              t_old_most_current_events_ = most_recent_stamp_at_coordXY.toSec();
            const double dt = (external_sync_time - most_recent_stamp_at_coordXY).toSec();
            representation_TS_.at<double>(y,x) = -dt / decay_sec_;
          }
        } // a most recent event is available
      }// loop x
    }// loop y

    ros::Time ts_old(t_new_most_current_events_ - 0.03);
    ros::Time ts_new(t_new_most_current_events_);
    auto it_begin = EventBuffer_lower_bound(events_, ts_old);
    auto it_end = EventBuffer_lower_bound(events_, ts_new);
    size_t numEvents = std::distance(it_begin, it_end) + 1;

//    representation_TS_ *= 30;
    cv::exp(representation_TS_, representation_TS_);

    LOG(INFO) << "How many events occurred: " << numEvents;
  
  }

//   // compute SILC
  if(representation_mode_ == SILC)
  {
    auto it = InvolvedEvents_.begin();
    for(;it != InvolvedEvents_.end();it++)
    {
      dvs_msgs::Event e = *it;
      for(int dx = -r_; dx <= r_; dx++)
        for(int dy = -r_; dy <= r_; dy++)
        {
          if(e.x + dx < 0 || e.x + dx >= sensor_size_.width || e.y + dy < 0 || e.y + dy >= sensor_size_.height)
            continue;
          if(representation_SILC_.at<uchar>(e.y+dy, e.x+dx) >= representation_SILC_.at<uchar>(e.y, e.x)
            && representation_SILC_.at<uchar>(e.y+dy, e.x+dx) > 0)
            representation_SILC_.at<uchar>(e.y+dy, e.x+dx)--;
//            representation_SILC_.at<uchar>(e.y+dy, e.x+dx) = representation_SILC_.at<uchar>(e.y+dy, e.x+dx) - substraction_delta_;
        }
      representation_SILC_.at<uchar>(e.y, e.x) = SILC_bound_;
    }

  }

//   // compute SILC2
  if(representation_mode_ == SILC2)
  {
    representation_SILC2_.setTo(cv::Scalar(0));
    for(size_t y = 0; y < sensor_size_.height; y++)
      for(size_t x = 0; x < sensor_size_.width; x++)
      {
        for(int dx = -r_; dx <= r_; dx++)
          for(int dy = -r_; dy <= r_; dy++)
          {
            if(x + dx < 0 || x + dx >= sensor_size_.width || y + dy < 0 || y + dy >= sensor_size_.height)
              continue;
            dvs_msgs::Event ev, ev_nb;
            if(!pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &ev) ||
              !pEventQueueMat_->getMostRecentEventBeforeT(x+dx, y+dy, external_sync_time, &ev_nb))
              continue;
            if(ev.ts.toSec() < ev_nb.ts.toSec())
              representation_SILC2_.at<uchar>(y,x)++;
          }
      }
  }

//   // TOS
  if(representation_mode_ == TOS)
  {
    TicToc t;
    auto it = InvolvedEvents_.begin();// This is somehow different to the luvHarris paper. The paper may control the number of events used.
    ros::Time event_time = (*it).ts;
    int sums = 0;
    for(;it != InvolvedEvents_.end();it++)
    {

      sums++;
      dvs_msgs::Event e = *it;
      for(int dx = -k_tos_; dx <= k_tos_; dx++)
        for(int dy = -k_tos_; dy <= k_tos_; dy++)
        {
          if(e.x + dx < 0 || e.x + dx >= sensor_size_.width || e.y + dy < 0 || e.y + dy >= sensor_size_.height)
            continue;
//          if(e.polarity < 0)
//            continue;
          if(representation_TOS_.at<uchar>(e.y+dy, e.x+dx) >= 1)
            representation_TOS_.at<uchar>(e.y+dy, e.x+dx)=representation_TOS_.at<uchar>(e.y+dy, e.x+dx)-2;
//            representation_TOS_.at<uchar>(e.y+dy, e.x+dx) = representation_TOS_.at<uchar>(e.y+dy, e.x+dx) - substraction_delta_;
          if(representation_TOS_.at<uchar>(e.y+dy, e.x+dx) < T_tos_)
            representation_TOS_.at<uchar>(e.y+dy, e.x+dx) = 0;
        }
      representation_TOS_.at<uchar>(e.y, e.x) = 255;
    }
    //event_time = (*it).ts.toSec() - event_time;
    it--;
    //std::cout << "use time:" << t.toc() << std::endl;
    std::cout <<"This is event_time:" << ((*it).ts - event_time ).toSec() << std::endl;
    // std::cout <<"This is sums:" << sums << std::endl;
  }


  //TOS3
  if(representation_mode_ == TOS3)
  {
    representation_TOS_ = cv::Mat::zeros(sensor_size_, CV_8UC1);
    cv::Mat sum_mat = cv::Mat::zeros(sensor_size_, CV_64F);
    

    cv::Rect rect_roi = cv::Rect(160, 80, 80, 80);
    cv::Rect rect_rois[48];
    for(int x = 0; x < 8; x++)
    {
      for(int y = 0; y < 6; y++)
      {
        rect_rois[8 * y + x] = cv::Rect(80 * x, 80 * y, 80, 80);
      }
    }
    rect_roi = rect_rois[5];

    bool flags[48] = {true};
    int all_flags = 0;
    for(int i= 0; i < 48; i++){
      flags[i] = true;
    }

    auto it = InvolvedEvents_.begin();// This is somehow different to the luvHarris paper. The paper may control the number of events used.
    ros::Time event_time = (*it).ts;
    int sums = 0;
    bool flag = true;

    for(;it != InvolvedEvents_.end();it++)
    {
      sums++;
      dvs_msgs::Event e = *it;
      if(sum_mat.at<double>(e.y, e.x) >= 1)
      {
        representation_TOS_.at<uchar>(e.y, e.x) = 255;
      }
      sum_mat.at<double>(e.y, e.x)++;
      if((e.ts - event_time).toSec() >= 0.002)
      {
        cv::Mat sum_mat_copy = sum_mat.clone();
        for(int i = 0; i < 48; i++)
        {
          if(flags[i] == true){

            cv::Mat rec_sum_mat = sum_mat_copy(rect_rois[i]);
            double score = cal_contrast(rec_sum_mat);
            if(score > 0.5)
            {
              cv::Mat temp_image = representation_TOS_(rect_rois[i]);
              temp_image.copyTo(TOS_copy(rect_rois[i]));
              flags[i] = false;
              all_flags++;
            }
          }
        }
        // cv::Mat rec_sum_mat = sum_mat_copy(rect_roi);
        // //TicToc t;
        // double score = cal_contrast(rec_sum_mat);
        // // std::cout << "use_time:" << t.toc() << std::endl;
        // std::cout <<"This is contrast:" << score << std::endl;
        event_time = e.ts;
        // if(score > 0.5)
        // {
        //   TOS_copy = representation_TOS_.clone();
        //   rectangle_image = TOS_copy(rect_roi);
        //   flag = false;
        // }
      } 
      if(all_flags > 40)
        break;
    }
    for(int i = 0; i < 48; i++)
    {
      if(flags[i] == true)
      {
        cv::Mat temp_image = representation_TOS_(rect_rois[i]);
        temp_image.copyTo(TOS_copy(rect_rois[i]));
        flags[i] = false;
      }
    }
    std::cout << "sums: " << sums<< std::endl;


    //event_filter(TOS_copy);
    // representation_TOS_ = TOS_copy.clone();
    // cv::Mat temp_image;
    // edge_extraction(TOS_copy, temp_image);
    // TOS_copy.convertTo(TOS_copy, CV_64F);
    // TOS_copy = TOS_copy.mul(temp_image);
    // TOS_copy.convertTo(TOS_copy, CV_8UC1);


    // TOS_copy.convertTo(TOS_copy, CV_64F);
    // cv::normalize(sum_mat, sum_mat, 0, 1, cv::NORM_MINMAX);
    // TOS_copy = TOS_copy.mul(sum_mat);
    // TOS_copy.convertTo(TOS_copy, CV_8UC1);
    // if(flag == true)
    //   rectangle_image = representation_TOS_(rect_roi);

    //cv::rectangle(representation_TOS_, rect_roi, 120, 1);
  
    //event_time = (*it).ts.toSec() - event_time;
    it--;
    
    //std::cout <<"This is event_time:" << ((*it).ts - event_time ).toSec() << std::endl;
    //std::cout <<"This is contrast:" << cal_contrast(rec_sum_mat) << std::endl;
    //std::cout <<"This is size:" << sensor_size_ << std::endl;
  }
  // TOS2
  if(representation_mode_ == TOS2)// TOS .* TS
  {
    representation_TS_.setTo(cv::Scalar(0));
    representation_TOS2_.setTo(cv::Scalar(0));
    // TS
    for(int y = 0; y < sensor_size_.height; ++y)
    {
      for (int x = 0; x < sensor_size_.width; ++x)
      {
        dvs_msgs::Event ev0;
        if (!pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &ev0))
          continue;
        const ros::Time &most_recent_stamp_at_coordXY = ev0.ts;
        if (most_recent_stamp_at_coordXY.toSec() > 0)
        {
          const double dt = (external_sync_time - most_recent_stamp_at_coordXY).toSec();
          representation_TS_.at<double>(y, x) = std::exp(-dt / decay_sec_);
        }
      }
    }
  //TOS
    auto it = InvolvedEvents_.begin();// This is somehow different to the luvHarris paper. The paper may control the number of events used.
    for(;it != InvolvedEvents_.end();it++)
    {
      dvs_msgs::Event e = *it;
      for(int dx = -k_tos_; dx <= k_tos_; dx++)
        for(int dy = -k_tos_; dy <= k_tos_; dy++)
        {
          if(e.x + dx < 0 || e.x + dx >= sensor_size_.width || e.y + dy < 0 || e.y + dy >= sensor_size_.height)
            continue;
//          if(e.polarity < 0)
//            continue;
          if(representation_TOS_.at<uchar>(e.y+dy, e.x+dx) >= 1)
            representation_TOS_.at<uchar>(e.y+dy, e.x+dx) = representation_TOS_.at<uchar>(e.y+dy, e.x+dx)-1;
//            representation_TOS_.at<uchar>(e.y+dy, e.x+dx) = representation_TOS_.at<uchar>(e.y+dy, e.x+dx) - substraction_delta_;
          if(representation_TOS_.at<uchar>(e.y+dy, e.x+dx) < T_tos_)
            representation_TOS_.at<uchar>(e.y+dy, e.x+dx) = 0;
        }
      representation_TOS_.at<uchar>(e.y, e.x) = 255;
    }

    //   cv::Mat filiter_image = cv::Mat::zeros(sensor_size_, CV_8UC1);
    //   cv::GaussianBlur(representation_TOS_, filiter_image, cv::Size(5, 5),5 ,5 );
    //   cv::Mat filiter_image2 = cv::Mat::zeros(sensor_size_, CV_8UC1);
    //   filiter_image2 = representation_TOS_.clone();
    //   uchar* ptr = filiter_image.ptr();
    //   int kernel_size = 0;
    //   for(int x = 0; x < sensor_size_.width; x++){
    //     for(int y = 0; y < sensor_size_.height;y++){
    //       //std::cout << __LINE__ << std::endl;
    //       if(x - kernel_size < 0 || x + kernel_size >= sensor_size_.width || y - kernel_size < 0 || y + kernel_size >= sensor_size_.height )
    //         continue;
    //       //std::cout << __LINE__ << std::endl;
    //       int score = 0;
    //       for(int i = -kernel_size; i <= kernel_size; i++){
    //         for(int j = -kernel_size; j <= kernel_size; j++){
    //           score += ptr[(x+i) * sensor_size_.width + y+j];
    //         }
    //       }
    //       if(score < T_tos_/2){
    //         filiter_image2.at<uchar>(y, x) = 0;
    //       }
    //     }

    //   }
    // representation_TOS_ = filiter_image2.clone();
    cv::Mat TOS_img = cv::Mat::zeros(sensor_size_, CV_8UC1);
    TOS_img = representation_TOS_;
    // cv::GaussianBlur(TOS_img, TOS_img, 3);
    TOS_img.convertTo(TOS_img, CV_64F);
    representation_TOS2_ = TOS_img.mul(representation_TS_);

  }

  // DiST
  if(representation_mode_ == DiST)
  {
    TicToc tt;
    representation_DiST_.setTo(cv::Scalar(0));
    std::map<double, std::pair<int, int> > SortedTimestampCoordinateMap;
    std::vector<std::pair<double, std::pair<int, int> > > ts_coord_vec;
    ts_coord_vec.reserve(sensor_size_.height * sensor_size_.width);

    // Compute DiT (TODO: to hyper threaded)
    for(int y=0; y<sensor_size_.height; ++y)
    {
      for (int x = 0; x < sensor_size_.width; ++x)
      {
        dvs_msgs::Event ev0;
        if (!pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &ev0))
          continue;

        if(ev0.polarity < 0) continue;

        int count = 0;
        double t_new = 0;
        double t_old = DBL_MAX;

        for (int dx = -rho_; dx <= rho_; dx++)
          for (int dy = -rho_; dy <= rho_; dy++)
          {
            int ev_rho_x = ev0.x + dx;
            int ev_rho_y = ev0.y + dy;
            if (ev_rho_x < 0 || ev_rho_x >= sensor_size_.width || ev_rho_y < 0 || ev_rho_y >= sensor_size_.height)
              continue;
            dvs_msgs::Event ev_rho;
            if (pEventQueueMat_->getMostRecentEventBeforeT(ev_rho_x, ev_rho_y, external_sync_time, &ev_rho))
            {
              if(ev_rho.polarity < 0) continue;//TODO
              count++;
              if(ev_rho.ts.toSec() > t_new)
                t_new = ev_rho.ts.toSec();
              if(ev_rho.ts.toSec() < t_old)
                t_old = ev_rho.ts.toSec();
            }
          }

        if(count > 0)
        {
          double D = (t_new - t_old) / count;
          ts_coord_vec.push_back(std::make_pair(ev0.ts.toSec() - alpha_ * D, std::make_pair<int, int>(ev0.x, ev0.y)));
        }
      }
    }

//    LOG(INFO) << "Compute DiT: " << tt.toc() << " ms.";
    tt.tic();

    // global sorting and normalization
    std::sort(ts_coord_vec.begin(), ts_coord_vec.end());
    for(int i = 0; i < ts_coord_vec.size(); i++)
    {
      double val = 1.0 * i / ts_coord_vec.size();
      if(val > truncate_)
        representation_DiST_.at<double>(ts_coord_vec[i].second.second, ts_coord_vec[i].second.first)
        = val;
      else
        representation_DiST_.at<double>(ts_coord_vec[i].second.second, ts_coord_vec[i].second.first)
          = 0;
    }
//    LOG(INFO) << "Compute DiST: " << tt.toc() << " ms.";
//    std::this_thread::sleep_for (std::chrono::milliseconds(100));
  }

  if(representation_mode_ == DiTTOS)
  {
    TicToc tt;
    representation_DiTTOS_.setTo(cv::Scalar(0));
    std::vector<std::pair<double, std::pair<int, int> > > ts_coord_vec;
    ts_coord_vec.reserve(sensor_size_.height * sensor_size_.width);

    // Compute DiT (TODO: to hyper threaded)
    for(int y=0; y<sensor_size_.height; ++y)
    {
      for (int x = 0; x < sensor_size_.width; ++x)
      {
        dvs_msgs::Event ev0;
        if (!pEventQueueMat_->getMostRecentEventBeforeT(x, y, external_sync_time, &ev0))
          continue;

//        if(ev0.polarity < 0) continue;

        int count = 0;
        double t_new = 0;
        double t_old = DBL_MAX;

        for (int dx = -rho_; dx <= rho_; dx++)
          for (int dy = -rho_; dy <= rho_; dy++)
          {
            int ev_rho_x = ev0.x + dx;
            int ev_rho_y = ev0.y + dy;
            if (ev_rho_x < 0 || ev_rho_x >= sensor_size_.width || ev_rho_y < 0 || ev_rho_y >= sensor_size_.height)
              continue;
            dvs_msgs::Event ev_rho;
            if (pEventQueueMat_->getMostRecentEventBeforeT(ev_rho_x, ev_rho_y, external_sync_time, &ev_rho))
            {
//              if(ev_rho.polarity < 0) continue;//TODO
              count++;
              if(ev_rho.ts.toSec() > t_new)
                t_new = ev_rho.ts.toSec();
              if(ev_rho.ts.toSec() < t_old)
                t_old = ev_rho.ts.toSec();
            }
          }

        if(count > 0)
        {
          double D = (t_new - t_old) / count;
          ts_coord_vec.push_back(std::make_pair(ev0.ts.toSec() - alpha_ * D, std::make_pair<int, int>(ev0.x, ev0.y)));
        }
      }
    }
    LOG(INFO) << "Compute DiT: " << tt.toc() << " ms.";
    tt.tic();

    std::sort(ts_coord_vec.begin(), ts_coord_vec.end());
    for(int i = 0; i < ts_coord_vec.size(); i++)
    {
      double val = 1.0 * i / ts_coord_vec.size();
      int x = ts_coord_vec[i].second.first;
      int y = ts_coord_vec[i].second.second;
      if(val > truncate_)
      {
        // TOS
        for(int dx = -k_tos_; dx <= k_tos_; dx++)
          for(int dy = -k_tos_; dy <= k_tos_; dy++)
          {
            if(x + dx < 0 || x + dx >= sensor_size_.width || y + dy < 0 || y + dy >= sensor_size_.height)
              continue;
            if(representation_DiTTOS_.at<uchar>(y+dy, x+dx) >= 1)
              representation_DiTTOS_.at<uchar>(y+dy, x+dx)--;
//              representation_DiTTOS_.at<uchar>(y+dy, x+dx)  = representation_DiTTOS_.at<uchar>(y+dy, x+dx) - substraction_delta_;
            if(representation_DiTTOS_.at<uchar>(y+dy, x+dx) < T_tos_)
              representation_DiTTOS_.at<uchar>(y+dy, x+dx) = 0;
          }
        representation_DiTTOS_.at<uchar>(y, x) = 255;
      }
      else
        representation_DiTTOS_.at<uchar>(y, x) = 0;
    }
//    double DiT_max = ts_coord_vec.rbegin()->first;
//    for(int i = 0; i < ts_coord_vec.size(); i++)
//    {
//      int x = ts_coord_vec[i].second.first;
//      int y = ts_coord_vec[i].second.second;
//      const double dt = DiT_max - ts_coord_vec[i].first;
//      representation_DiTTOS_.at<uchar>(y,x) = std::floor(255.0 * std::exp(-dt));
//    }
    LOG(INFO) << "Compute TOS: " << tt.toc() << " ms.";
  }
  std::cout << "0 use_time:" << t_Linear_TS.toc() << std::endl;
//  // median blur
//  if(median_blur_kernel_size_ > 0)
//    cv::medianBlur(image_representation_map, image_representation_map, 2 * median_blur_kernel_size_ + 1);
//  LOG(INFO) << "000000000000000000000000000000000000000000";
  std::cout << "size:" << InvolvedEvents_.size() << std::endl;
  InvolvedEvents_.clear();
  x_.clear();
  y_.clear();
  t_.clear();
  std::cout << "1 use_time :" << t_Linear_TS.toc() << std::endl;
//  LOG(INFO) << "11111111111111111111111111111111111111111";

  // Publish image representation
  static cv_bridge::CvImage cv_image, cv_image_temp;
  cv_image.encoding = "mono8";
  cv_image_temp.encoding = "mono8";
  if(representation_mode_ == TS)
  {
    cv::Mat TS_img = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img = representation_TS_ * 255.0;
    TS_img.convertTo(TS_img, CV_8U);
    cv_image.image = TS_img.clone();

    cv::Mat TS_img_temp = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img_temp = filiter_image * 255.0;
    TS_img_temp.convertTo(TS_img_temp, CV_8U);
    // cv::Mat temp;
    // edge_extraction(TS_img_temp, temp);
    cv_image_temp.image = TS_img_temp.clone();
    // cv_image_temp.image = temp.clone();

  }
  if(representation_mode_ == Linear_TS)
  {
    cv::Mat TS_img = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img = representation_TS_ * 255.0;
    TS_img.convertTo(TS_img, CV_8U);
    cv_image.image = TS_img.clone();

    cv::Mat TS_img_temp = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img_temp = representation_TS_ * 255.0;
    TS_img_temp.convertTo(TS_img_temp, CV_8U);
    cv_image_temp.image = TS_img_temp.clone();

  }
  if(representation_mode_ == TS2)
  {
    cv::Mat TS_img = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img = representation_TS_ * 255.0;
    TS_img.convertTo(TS_img, CV_8U);
    cv_image.image = TS_img.clone();
  }
  if(representation_mode_ == SILC)
  {
    cv::Mat SILC_img = cv::Mat::zeros(sensor_size_, CV_64F);
    // Add a lock here
    SILC_img = 255.0 * representation_SILC_ / SILC_bound_;
    SILC_img.convertTo(SILC_img, CV_8U);
    cv_image.image = SILC_img.clone();
  }

  if(representation_mode_ == SILC2)
  {
    cv::Mat SILC2_img = cv::Mat::zeros(sensor_size_, CV_64F);
    // Add a lock here
    SILC2_img = 255.0 * representation_SILC2_ / SILC_bound_;
    SILC2_img.convertTo(SILC2_img, CV_8U);
    cv_image.image = SILC2_img.clone();
  }

  if(representation_mode_ == TOS)
  {
    cv_image.image = representation_TOS_.clone();
//    representation_TOS_.setTo(0);
  }
  if(representation_mode_ == TOS3)
  {
    cv_image.image = representation_TOS_.clone();
    //    representation_TOS_.setTo(0);
    cv_image_temp.image = TOS_copy.clone();
  }

  if(representation_mode_ == TOS2)
  {
    cv::Mat TOS2_img = cv::Mat::zeros(sensor_size_, CV_64F);
    TOS2_img = representation_TOS2_;
    // Add a lock here
    TOS2_img.convertTo(TOS2_img, CV_8U);
    cv_image.image = TOS2_img.clone();


    cv::Mat TS_img = cv::Mat::zeros(sensor_size_, CV_64F);
    TS_img = representation_TOS2_;
    //cv::GaussianBlur(TS_img, TS_img, cv::Size(5, 5),3 ,3 );
    // cv::Mat se = cv::getStructuringElement(0, cv::Size(2, 2)); //构造矩形结构元素

    // cv::dilate(representation_TOS2_, TS_img, se, cv::Point(-1, -1), 1); //执行膨胀操作
    // cv::erode(TS_img, TS_img, se, cv::Point(-1, -1), 1); //执行腐蚀操作

    //     cv::dilate(representation_TOS2_, TS_img, se, cv::Point(-1, -1), 1); //执行膨胀操作
    // cv::erode(TS_img, TS_img, se, cv::Point(-1, -1), 1); //执行腐蚀操作

    //     cv::dilate(representation_TOS2_, TS_img, se, cv::Point(-1, -1), 2); //执行膨胀操作
    // cv::erode(TS_img, TS_img, se, cv::Point(-1, -1), 2); //执行腐蚀操作

    //     cv::dilate(representation_TOS2_, TS_img, se, cv::Point(-1, -1), 2); //执行膨胀操作
    // cv::erode(TS_img, TS_img, se, cv::Point(-1, -1), 2); //执行腐蚀操作
    

    TS_img.convertTo(TS_img, CV_8U);
    cv_image_temp.image = TS_img.clone();
  }

  if(representation_mode_ == DiST)
  {
    cv::Mat DiST_img = cv::Mat::zeros(sensor_size_, CV_64F);
    DiST_img = 255.0 * representation_DiST_;
    DiST_img.convertTo(DiST_img, CV_8U);
    cv_image.image = DiST_img.clone();
  }

//  LOG(INFO) << "2222222222222222222222222222222222222222222222222222";

  if(representation_mode_ == DiTTOS)
  {
    cv_image.image = representation_DiTTOS_.clone();
  }

//  LOG(INFO) << "3333333333333333333333333333333333333333333333333333";
  if (bCamInfoAvailable_ )
  //if (bCamInfoAvailable_ && image_representation_pub_.getNumSubscribers() > 0)
  {
    cv_bridge::CvImage cv_image2;
    cv_image2.encoding = cv_image.encoding;
    cv_image2.header.stamp = external_sync_time;
    if(bUseStereoCam_)
      cv::remap(cv_image.image, cv_image2.image, undistort_map1_, undistort_map2_, CV_INTER_LINEAR);
    else
    {
      // TODO: undistortion
      cv_image2.image = cv_image.image;
    }
    cv_bridge::CvImage cv_image2_temp;
    cv_image2_temp.encoding = cv_image_temp.encoding;
    cv_image2_temp.header.stamp = external_sync_time;
    if(bUseStereoCam_)
      cv::remap(cv_image_temp.image, cv_image2_temp.image, undistort_map1_, undistort_map2_, CV_INTER_LINEAR);
    else
    {
      // TODO: undistortion
      cv_image2_temp.image = cv_image_temp.image;
    }
    image_representation_pub_.publish(cv_image2.toImageMsg());
    image_representation_temp_pub_.publish(cv_image2_temp.toImageMsg());

  }
//  LOG(INFO) << "Published image";
}

void ImageRepresentation::createImageRepresentationAtTime_hyperthread(const ros::Time &external_sync_time)
{
  std::lock_guard<std::mutex> lock(data_mutex_);
  if(!bSensorInitialized_ || !bCamInfoAvailable_)
    return;

  std::vector<Job1> jobs(NUM_THREAD_REPRESENTATION);
  // distribute jobs (TS, SILC2)
  if(representation_mode_ == TS || representation_mode_ == SILC2)
  {
    size_t num_col_per_thread = sensor_size_.width / NUM_THREAD_REPRESENTATION;
    size_t res_col = sensor_size_.width % NUM_THREAD_REPRESENTATION;
    for(size_t i = 0; i < NUM_THREAD_REPRESENTATION; i++)
    {
      jobs[i].i_thread_ = i;
      jobs[i].pEventQueueMat_ = pEventQueueMat_.get();
      if(representation_mode_ == TS)
        jobs[i].pRepresentation_ = &representation_TS_;
      if(representation_mode_ == SILC2)
        jobs[i].pRepresentation_ = &representation_SILC2_;

      jobs[i].start_col_ = num_col_per_thread * i;
      if(i == NUM_THREAD_REPRESENTATION - 1)
        jobs[i].end_col_ = jobs[i].start_col_ + num_col_per_thread - 1 + res_col;
      else
        jobs[i].end_col_ = jobs[i].start_col_ + num_col_per_thread - 1;
      jobs[i].start_row_ = 0;
      jobs[i].end_row_ = sensor_size_.height - 1;
      jobs[i].external_sync_time_ = external_sync_time;
      // parameters
      jobs[i].TS_param_decay_sec_ = decay_sec_;
      jobs[i].SILC2_param_r_ = r_;
//      jobs[i].Dist_para_rho_ = rho_;
//      jobs[i].DiST_para_alpha_ = alpha_;
    }
  }
  cv::Mat TOS_upper, TOS_lower = cv::Mat::zeros(cv::Size(sensor_size_.width, sensor_size_.height/2), CV_8UC1);

  std::vector<Job2> jobs2(NUM_THREAD_REPRESENTATION);
  // distribute jobs (SILC, TOS)
  if(representation_mode_ == SILC || representation_mode_ == TOS)
  {
    size_t num_event_per_thread = InvolvedEvents_.size() / NUM_THREAD_REPRESENTATION;
    size_t res_num = InvolvedEvents_.size() % NUM_THREAD_REPRESENTATION;
    for(size_t i = 0; i < NUM_THREAD_REPRESENTATION; i++)
    {
      jobs2[i].i_thread_ = i;
      if(i == 0)
        jobs2[i].pInvolvedEvents_ = &InvolvedEvents0_;
      else
        jobs2[i].pInvolvedEvents_ = &InvolvedEvents1_;
      if(representation_mode_ == SILC)
        jobs2[i].pRepresentation_ = &representation_SILC_;
      if(representation_mode_ == TOS){
        if(i == 0)
          jobs2[i].pRepresentation_ = &TOS_upper;
        else
          jobs2[i].pRepresentation_ = &TOS_lower;
      }
        
      jobs2[i].external_sync_time_ = external_sync_time;
      jobs2[i].SILC_param_r_ = r_;
      jobs2[i].SILC_param_bound_ = SILC_bound_;
      jobs2[i].TOS_param_k_ = k_tos_;
      jobs2[i].TOS_param_T_ = T_tos_;
    }
  }
  std::vector<std::vector<std::pair<double, std::pair<int, int> > > > vvTimestampCoordnate(NUM_THREAD_REPRESENTATION);
  if(representation_mode_ == DiST)
  {
    representation_DiST_.setTo(cv::Scalar(0));

    size_t num_col_per_thread = sensor_size_.width / NUM_THREAD_REPRESENTATION;
    size_t res_col = sensor_size_.width % NUM_THREAD_REPRESENTATION;
    for(size_t i = 0; i < NUM_THREAD_REPRESENTATION; i++)
    {
      jobs[i].i_thread_ = i;
      jobs[i].pEventQueueMat_ = pEventQueueMat_.get();
      jobs[i].pRepresentation_ = &representation_DiST_;
      jobs[i].start_col_ = num_col_per_thread * i;
      if(i == NUM_THREAD_REPRESENTATION - 1)
        jobs[i].end_col_ = jobs[i].start_col_ + num_col_per_thread - 1 + res_col;
      else
        jobs[i].end_col_ = jobs[i].start_col_ + num_col_per_thread - 1;
      jobs[i].start_row_ = 0;
      jobs[i].end_row_ = sensor_size_.height - 1;
      jobs[i].ptr_ts_coord_vec_ = &vvTimestampCoordnate[i];
      jobs[i].external_sync_time_ = external_sync_time;
      // parameters
      jobs[i].Dist_para_rho_ = rho_;
      jobs[i].DiST_para_alpha_ = alpha_;
    }
  }
//  LOG(INFO) << "999999999999999999999999999999999999999999999999";

  // hyper thread processing
  std::vector<std::thread> threads;
  threads.reserve(NUM_THREAD_REPRESENTATION);
  for(size_t i = 0; i < NUM_THREAD_REPRESENTATION; i++)
  {
    if(representation_mode_ == TS)
      threads.emplace_back(std::bind(&ImageRepresentation::TS_thread, this, jobs[i]));
    if(representation_mode_ == SILC)
      threads.emplace_back(std::bind(&ImageRepresentation::SILC_thread, this, jobs2[i]));
    if(representation_mode_ == SILC2)
      threads.emplace_back(std::bind(&ImageRepresentation::SILC2_thread, this, jobs[i]));
    if(representation_mode_ == TOS)
      threads.emplace_back(std::bind(&ImageRepresentation::TOS_thread, this, jobs2[i]));
    if(representation_mode_ == DiST)
      threads.emplace_back(std::bind(&ImageRepresentation::DiST_thread, this, jobs[i]));
  }
  for(auto& thread:threads)
    if(thread.joinable())
      thread.join();
//
//  // TODO: post processing
  if(representation_mode_ == DiST)
  {
    // sorting and normalization
    std::vector<std::pair<double, std::pair<int, int> > > ts_coord_vec_all;
    ts_coord_vec_all.reserve(sensor_size_.width * sensor_size_.height);
    for(auto& job:jobs)
      ts_coord_vec_all.insert(ts_coord_vec_all.end(), job.ptr_ts_coord_vec_->begin(), job.ptr_ts_coord_vec_->end());
    std::sort(ts_coord_vec_all.begin(), ts_coord_vec_all.end());
    for(int i = 0; i < ts_coord_vec_all.size(); i++)
    {
      representation_DiST_.at<double>(ts_coord_vec_all[i].second.second, ts_coord_vec_all[i].second.first)
        = 1.0 * i / ts_coord_vec_all.size();
    }
  }
  // publish result
  
    static cv_bridge::CvImage cv_image;
    cv_image.encoding = "mono8";
    if (representation_mode_ == TS)
    {
      cv::Mat TS_img = cv::Mat::zeros(sensor_size_, CV_64F);
      TS_img = representation_TS_ * 255.0;
      TS_img.convertTo(TS_img, CV_8U);
      cv_image.image = TS_img.clone();
    }
    if (representation_mode_ == SILC)
    {
      cv::Mat SILC_img = cv::Mat::zeros(sensor_size_, CV_64F);
      // Add a lock here
      SILC_img = 255.0 * representation_SILC_ / SILC_bound_;
      SILC_img.convertTo(SILC_img, CV_8U);
      cv_image.image = SILC_img.clone();
    }

    if (representation_mode_ == SILC2)
    {
      cv::Mat SILC2_img = cv::Mat::zeros(sensor_size_, CV_64F);
      // Add a lock here
      SILC2_img = 255.0 * representation_SILC2_ / SILC_bound_;
      SILC2_img.convertTo(SILC2_img, CV_8U);
      cv_image.image = SILC2_img.clone();
    }

    if (representation_mode_ == TOS)
    {
      //cv::Mat TOS_upper, TOS_lower = cv::Mat::zeros(cv::Size(sensor_size_.width, sensor_size_.height/2), CV_8UC1);
      TOS_upper.copyTo(representation_TOS_(cv::Rect(0, 0, 640, 240)));
      TOS_lower.copyTo(representation_TOS_(cv::Rect(0, 240, 640, 240)));
      cv_image.image = representation_TOS_.clone();
//    representation_TOS_.setTo(0);
    }//bag_src

    if (representation_mode_ == DiST)
    {
      cv::Mat DiST_img = cv::Mat::zeros(sensor_size_, CV_64F);
      DiST_img = 255.0 * representation_DiST_;
      DiST_img.convertTo(DiST_img, CV_8U);
      cv_image.image = DiST_img.clone();
    }

    if (bCamInfoAvailable_ && image_representation_pub_.getNumSubscribers() > 0)
    {
      cv_bridge::CvImage cv_image2;
      cv_image2.encoding = cv_image.encoding;
      cv_image2.header.stamp = external_sync_time;
      if(bUseStereoCam_)
        cv::remap(cv_image.image, cv_image2.image, undistort_map1_, undistort_map2_, CV_INTER_LINEAR);
      else
      {
        // TODO: undistortion
        cv_image2.image = cv_image.image;
      }
      image_representation_pub_.publish(cv_image2.toImageMsg());
    }
  InvolvedEvents0_.clear();
  InvolvedEvents1_.clear();
}

void ImageRepresentation::TS_thread(Job1 &job)
{
  EventQueueMat & eqMat = *job.pEventQueueMat_;
  cv::Mat& time_surface_map = *job.pRepresentation_;
  size_t start_col = job.start_col_;
  size_t end_col = job.end_col_;
  size_t start_row = job.start_row_;
  size_t end_row = job.end_row_;

  for(size_t y = start_row; y <= end_row; y++)
    for(size_t x = start_col; x <= end_col; x++)
    {
      dvs_msgs::Event most_recent_event_at_coordXY_before_T;
      if (pEventQueueMat_->getMostRecentEventBeforeT(x, y, job.external_sync_time_, &most_recent_event_at_coordXY_before_T))
      {
        const ros::Time& most_recent_stamp_at_coordXY = most_recent_event_at_coordXY_before_T.ts;
        if(most_recent_stamp_at_coordXY.toSec() > 0)
        {
          const double dt = (job.external_sync_time_ - most_recent_stamp_at_coordXY).toSec();
          time_surface_map.at<double>(y,x) = std::exp(-dt / job.TS_param_decay_sec_);
        }
      }
    }
}
void ImageRepresentation::SILC_thread(Job2 &job){}
void ImageRepresentation::SILC2_thread(Job1 &job){}
void ImageRepresentation::TOS_thread(Job2 &job)
{
  cv::Size half_seensor_size_ = cv::Size(sensor_size_.width, sensor_size_.height/2);
  cv::Mat TOS = cv::Mat::zeros(half_seensor_size_, CV_8UC1);
  cv::Mat TOS_copy = cv::Mat::zeros(half_seensor_size_, CV_8UC1);
  
  //representation_TOS_ = cv::Mat::zeros(sensor_size_, CV_8UC1);
  cv::Mat sum_mat = cv::Mat::zeros(half_seensor_size_, CV_64F);
  

  //cv::Rect rect_roi = cv::Rect(160, 80, 80, 80);
  cv::Rect rect_rois[24];
  for(int x = 0; x < 8; x++)
  {
    for(int y = 0; y < 3; y++)
    {
      rect_rois[8 * y + x] = cv::Rect(80 * x, 80 * y, 80, 80);
    }
  }
  //rect_roi = rect_rois[5];
  bool flags[24];
  double scores[24];
  for(int i= 0; i < 24; i++){
    flags[i] = true;
    scores[i] = 0;
  }
  


  auto it = job.pInvolvedEvents_->begin();// This is somehow different to the luvHarris paper. The paper may control the number of events used.


  ros::Time event_time = (*it).ts;
  int sums = 0;
  int all_flag = 0;
  TicToc t;
  if(job.pInvolvedEvents_->size() > 500000)
  {
    std::cout << "111111111111111111111111111" << std::endl;
  }
  //std::cout << "events size:" << job.pInvolvedEvents_->size() << std::endl;
  for(;it != job.pInvolvedEvents_->end();it++)
  {
    sums++;
    all_flag = 0;
    dvs_msgs::Event e = *it;
    if(sum_mat.at<double>(e.y - (job.i_thread_) * 240, e.x) >= 1)
    {
      TOS.at<uchar>(e.y - (job.i_thread_) * 240, e.x) = 255;
    }
    sum_mat.at<double>(e.y - (job.i_thread_) * 240, e.x)++;
    if((e.ts - event_time).toSec() >= 0.002)
    {
      cv::Mat sum_mat_copy = sum_mat.clone();
      for(int i = 0; i < 24; i++)
      {
        if(flags[i] == true){

          cv::Mat rec_sum_mat = sum_mat_copy(rect_rois[i]);
          double score = cal_contrast(rec_sum_mat);
          scores[i] = score;
          if(score > 0.5)
          {
            cv::Mat temp_image = TOS(rect_rois[i]);
            temp_image.copyTo(TOS_copy(rect_rois[i]));
            flags[i] = false;
            all_flag++;
          }
        }
        // else {
        //   all_flag++;
        // }
      }
      // cv::Mat rec_sum_mat = sum_mat_copy(rect_roi);
      // //TicToc t;
      // double score = cal_contrast(rec_sum_mat);
      // // std::cout << "use_time:" << t.toc() << std::endl;
      // std::cout <<"This is contrast:" << score << std::endl;
      event_time = e.ts;
      // if(score > 0.5)
      // {
      //   TOS_copy = representation_TOS_.clone();
      //   rectangle_image = TOS_copy(rect_roi);
      //   flag = false;
      // }
    } 
    if(all_flag == 24){
      //std::cout << "yes" << std::endl;
      break;
    }
  }
  //std::cout << "use_time_all:" << t.toc() << std::endl;
  //std::cout << " " << std::endl;

  // for(int y = 0; y < sum_mat.rows; y++){
  //       for(int x = 0; x < sum_mat.cols; x++){
  //         if(sum_mat.at<double>(y, x) == 1)
  //         {
  //           TOS.at<uchar>(y, x) = 255;
  //         }
  //       }
  //     }

  for(int i = 0; i < 24; i++)
  {
    if(flags[i] == true)
    {
      if(scores[i] < 0.2)
      {
        int cols = i % 8;
        int rows = (i - cols) / 8;
        for(int y = rows; y < rows + 80; y++)
        {
          for(int x = cols; x < cols + 80; x++)
          {
            if(sum_mat.at<double>(y, x) == 1)
            {
              TOS.at<uchar>(y, x) = 255;
            }
          }
        }
      }
      cv::Mat temp_image = TOS(rect_rois[i]);
      temp_image.copyTo(TOS_copy(rect_rois[i]));
      flags[i] = false;
    }
  }

  //event_filter(TOS_copy);
  // representation_TOS_ = TOS_copy.clone();
  // cv::Mat temp_image;
  // edge_extraction(TOS_copy, temp_image);
  // TOS_copy.convertTo(TOS_copy, CV_64F);
  // TOS_copy = TOS_copy.mul(temp_image);
  // TOS_copy.convertTo(TOS_copy, CV_8UC1);


  // TOS_copy.convertTo(TOS_copy, CV_64F);
  // cv::normalize(sum_mat, sum_mat, 0, 1, cv::NORM_MINMAX);
  // TOS_copy = TOS_copy.mul(sum_mat);
  // TOS_copy.convertTo(TOS_copy, CV_8UC1);
  // if(flag == true)
  //   rectangle_image = representation_TOS_(rect_roi);

  //cv::rectangle(representation_TOS_, rect_roi, 120, 1);

  //event_time = (*it).ts.toSec() - event_time;
  it--;
  
  //std::cout <<"This is event_time:" << ((*it).ts - event_time ).toSec() << std::endl;
  //std::cout <<"This is contrast:" << cal_contrast(rec_sum_mat) << std::endl;
  //std::cout <<"This is size:" << sensor_size_ << std::endl;
  *(job.pRepresentation_) = TOS_copy.clone();

}

void ImageRepresentation::DiST_thread(Job1 &job)
{
  EventQueueMat & eqMat = *job.pEventQueueMat_;
  cv::Mat& time_surface_map = *job.pRepresentation_;
  size_t start_col = job.start_col_;
  size_t end_col = job.end_col_;
  size_t start_row = job.start_row_;
  size_t end_row = job.end_row_;
  std::vector<std::pair<double, std::pair<int, int> > >& ts_coord_vec = *job.ptr_ts_coord_vec_;
  ts_coord_vec.reserve(sensor_size_.width * sensor_size_.height);

  // compute DiT
  for(size_t y = start_row; y <= end_row; y++)
    for(size_t x = start_col; x <= end_col; x++)
    {
      dvs_msgs::Event ev0;
      if (!pEventQueueMat_->getMostRecentEventBeforeT(x, y, job.external_sync_time_, &ev0))
        continue;

      int count = 0;
      double t_new = 0;
      double t_old = DBL_MAX;

      for (int dx = -job.Dist_para_rho_; dx <= job.Dist_para_rho_; dx++)
        for (int dy = -job.Dist_para_rho_; dy <= job.Dist_para_rho_; dy++)
        {
          int ev_rho_x = ev0.x + dx;
          int ev_rho_y = ev0.y + dy;
          if (ev_rho_x < 0 || ev_rho_x >= sensor_size_.width || ev_rho_y < 0 || ev_rho_y >= sensor_size_.height)
            continue;
          dvs_msgs::Event ev_rho;
          if (pEventQueueMat_->getMostRecentEventBeforeT(ev_rho_x, ev_rho_y, job.external_sync_time_, &ev_rho))
          {
//              if(ev_rho.polarity < 0) continue;//TODO
            count++;
            if(ev_rho.ts.toSec() > t_new)
              t_new = ev_rho.ts.toSec();
            if(ev_rho.ts.toSec() < t_old)
              t_old = ev_rho.ts.toSec();
          }
        }

      if(count > 0)
      {
        double D = (t_new - t_old) / count;
        ts_coord_vec.push_back(std::make_pair(ev0.ts.toSec() - alpha_ * D, std::make_pair<int, int>(ev0.x, ev0.y)));
      }
    }
}

void ImageRepresentation::syncCallback(const std_msgs::TimeConstPtr& msg)
{
  if(bUse_Sim_Time_)
    sync_time_ = ros::Time::now();
  else
    sync_time_ = msg->data;

//#ifdef ESVO_TS_LOG
//    TicToc tt;
//    tt.tic();
//#endif
    if(NUM_THREAD_REPRESENTATION == 1)
      createImageRepresentationAtTime(sync_time_);
    if(NUM_THREAD_REPRESENTATION > 1)
      createImageRepresentationAtTime_hyperthread(sync_time_);
//#ifdef ESVO_TS_LOG
//    LOG(INFO) << "Time Surface map's creation takes: " << tt.toc() << " ms.";
//#endif
}

void ImageRepresentation::cameraInfoCallback(const sensor_msgs::CameraInfo::ConstPtr& msg)
{
  if(bCamInfoAvailable_)
    return;

  cv::Size sensor_size(msg->width, msg->height);
  camera_matrix_ = cv::Mat(3, 3, CV_64F);
  for (int i = 0; i < 3; i++)
    for (int j = 0; j < 3; j++)
      camera_matrix_.at<double>(cv::Point(i, j)) = msg->K[i+j*3];

  distortion_model_ = msg->distortion_model;
  dist_coeffs_ = cv::Mat(msg->D.size(), 1, CV_64F);
  for (int i = 0; i < msg->D.size(); i++)
    dist_coeffs_.at<double>(i) = msg->D[i];

  if(bUseStereoCam_)
  {
    rectification_matrix_ = cv::Mat(3, 3, CV_64F);
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        rectification_matrix_.at<double>(cv::Point(i, j)) = msg->R[i+j*3];

    projection_matrix_ = cv::Mat(3, 4, CV_64F);
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 3; j++)
        projection_matrix_.at<double>(cv::Point(i, j)) = msg->P[i+j*4];

    if(distortion_model_ == "equidistant")
    {
      cv::fisheye::initUndistortRectifyMap(camera_matrix_, dist_coeffs_,
                                           rectification_matrix_, projection_matrix_,
                                           sensor_size, CV_32FC1, undistort_map1_, undistort_map2_);
      bCamInfoAvailable_ = true;
      ROS_INFO("Camera information is loaded (Distortion model %s).", distortion_model_.c_str());
    }
    else if(distortion_model_ == "plumb_bob")
    {
      cv::initUndistortRectifyMap(camera_matrix_, dist_coeffs_,
                                  rectification_matrix_, projection_matrix_,
                                  sensor_size, CV_32FC1, undistort_map1_, undistort_map2_);
      bCamInfoAvailable_ = true;
      ROS_INFO("Camera information is loaded (Distortion model %s).", distortion_model_.c_str());
    }
    else
    {
      ROS_ERROR_ONCE("Distortion model %s is not supported.", distortion_model_.c_str());
      bCamInfoAvailable_ = false;
      return;
    }

    /* pre-compute the undistorted-rectified look-up table */
    precomputed_rectified_points_ = Eigen::Matrix2Xd(2, sensor_size.height * sensor_size.width);
    // raw coordinates
    cv::Mat_<cv::Point2f> RawCoordinates(1, sensor_size.height * sensor_size.width);
    for (int y = 0; y < sensor_size.height; y++)
    {
      for (int x = 0; x < sensor_size.width; x++)
      {
        int index = y * sensor_size.width + x;
        RawCoordinates(index) = cv::Point2f((float) x, (float) y);
      }
    }
    // undistorted-rectified coordinates
    cv::Mat_<cv::Point2f> RectCoordinates(1, sensor_size.height * sensor_size.width);
    if (distortion_model_ == "plumb_bob")
    {
      cv::undistortPoints(RawCoordinates, RectCoordinates, camera_matrix_, dist_coeffs_,
                          rectification_matrix_, projection_matrix_);
      ROS_INFO("Undistorted-Rectified Look-Up Table with Distortion model: %s", distortion_model_.c_str());
    }
    else if (distortion_model_ == "equidistant")
    {
      cv::fisheye::undistortPoints(
        RawCoordinates, RectCoordinates, camera_matrix_, dist_coeffs_,
        rectification_matrix_, projection_matrix_);
      ROS_INFO("Undistorted-Rectified Look-Up Table with Distortion model: %s", distortion_model_.c_str());
    }
    else
    {
      std::cout << "Unknown distortion model is provided." << std::endl;
      exit(-1);
    }
    // load look-up table
    for (size_t i = 0; i < sensor_size.height * sensor_size.width; i++)
    {
      precomputed_rectified_points_.col(i) = Eigen::Matrix<double, 2, 1>(
        RectCoordinates(i).x, RectCoordinates(i).y);
    }
    ROS_INFO("Undistorted-Rectified Look-Up Table has been computed.");
  }
  else
  {
    // TODO: calculate undistortion map
    bCamInfoAvailable_ = true;
  }
}

void ImageRepresentation::eventsCallback(const dvs_msgs::EventArray::ConstPtr& msg)
{
  std::lock_guard<std::mutex> lock(data_mutex_);
  if(!bSensorInitialized_)
    init(msg->width, msg->height);
  if(NUM_THREAD_REPRESENTATION == 2)
    for(const dvs_msgs::Event& e : msg->events)
    {
      events_.push_back(e);
      //InvolvedEvents_.push_back(e);
      int i = events_.size() - 2;
      while(i >= 0 && events_[i].ts > e.ts)
      {
        events_[i+1] = events_[i];
        i--;
      }
      events_[i+1] = e;

      const dvs_msgs::Event& last_event = events_.back();
      if(e.y < sensor_size_.height/2)
      {
        InvolvedEvents0_.push_back(last_event);
      }
      else
      {
        InvolvedEvents1_.push_back(last_event);
      }
    }
  else
    for(const dvs_msgs::Event& e : msg->events)
    {
      events_.push_back(e);
      x_.push_back(e.x);
      y_.push_back(e.y);
      t_.push_back(e.ts.toSec());
      InvolvedEvents_.push_back(e);
      int i = events_.size() - 2;
      while(i >= 0 && events_[i].ts > e.ts)
      {
        events_[i+1] = events_[i];
        i--;
      }
      events_[i+1] = e;

      const dvs_msgs::Event& last_event = events_.back();
      //pEventQueueMat_->insertEvent(last_event);

      //last_time_ = e.ts;
    }
  clearEventQueue();
}

void ImageRepresentation::clearEventQueue()
{
  static constexpr size_t MAX_EVENT_QUEUE_LENGTH = 5000000;
  if (events_.size() > MAX_EVENT_QUEUE_LENGTH)
  {
    size_t remove_events = events_.size() - MAX_EVENT_QUEUE_LENGTH;
    events_.erase(events_.begin(), events_.begin() + remove_events);
  
    //size_t remove_event = x_.size() - MAX_EVENT_QUEUE_LENGTH;
    // x_.erase(x_.begin(), x_.begin() + remove_events);
    // y_.erase(y_.begin(), y_.begin() + remove_events);
    // t_.erase(t_.begin(), t_.begin() + remove_events);
  }
}

} // namespace esvio_image_representation